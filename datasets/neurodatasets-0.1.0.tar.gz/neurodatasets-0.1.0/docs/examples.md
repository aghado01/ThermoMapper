# neurodatasets – Examples

This page provides practical examples of using `neurodatasets` for data analysis and exploration.

## Basic Examples

### Example 1: Loading and Exploring a Dataset

Learn how to load a dataset and perform basic exploration.

```python
import neurodatasets as nd

# Load the speech signal features dataset for Parkinson's disease classification
parkinson_001 = nd.load_dataset("parkinson_speech")

# Display first few rows
print(parkinson_001.head())

# Check dataset shape
print(f"\nDataset shape: {parkinson_001.shape}")

# View column names
print(f"\nColumns: {list(parkinson_001.columns)}")

# Get summary statistics
print("\nSummary statistics:")
print(parkinson_001.describe())

# Check for missing values
print("\nMissing values:")
print(parkinson_001.isnull().sum())

```

### Example 2: Exploring seizure counts from epileptic patients in a clinical trial

```python
import neurodatasets as nd

# Load Seizure counts from epileptic patients in a clinical trial
epilepsy_001 = nd.load_dataset("epilepsy_seizures")

# Display first few rows
print(epilepsy_001.head())

# Check dataset shape
print(f"\nDataset shape: {epilepsy_001.shape}")

# View column names
print(f"\nColumns: {list(epilepsy_001.columns)}")

```

### Example 3: Exploring Alzheimer's disease biomarkers

```python

import neurodatasets as nd

alzheimer_001 = nd.load_dataset("alzheimers_biomarkers")
print(alzheimer_001.head())
print(f"\nDataset shape: {alzheimer_001.shape}")
print(f"\nColumns: {list(alzheimer_001.columns)}")

```

### Example 4: Listing all available datasets

```python

import neurodatasets as nd

datasets = nd.list_datasets()
print(datasets)

```