# Changelog

All notable changes to `neurodatasets` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-25

### Added
- Initial release of `neurodatasets`
- Access to a curated collection of neuroscience and brain-related datasets for data analysis, statistical modeling, and machine learning research in Python.
- Basic documentation and usage examples
