from setuptools import setup, find_packages
import os

# Read the contents of README.md
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="neurodatasets",
    version="0.1.0",
    author="Renzo Caceres Rossi",
    author_email="arenzocaceresrossi@gmail.com",
    description=(
        "A curated collection of neuroscience and brain-related datasets for "
    "data analysis, statistical modeling, and machine learning research. "
    "Includes biomedical voice recordings, MRI brain imaging, Alzheimer's "
    "and Parkinson's disease biomarkers, epilepsy seizures, ADHD symptoms, "
    "dopamine and serotonin measurements, cognitive impairment, brain size "
    "across species, sleep studies, PTSD, migraine treatment, and more "
    "from curated R packages on CRAN."
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/lightbluetitan/neurodatasets-py",
    project_urls={
        "Bug Tracker": "https://github.com/lightbluetitan/neurodatasets-py/issues",
        "Documentation": "https://github.com/lightbluetitan/neurodatasets-py",
        "Source Code": "https://github.com/lightbluetitan/neurodatasets-py",
    },
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "neurodatasets": [
            "data/*.csv",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
    
    # Audience
    "Intended Audience :: Developers",
    "Intended Audience :: Education",
    "Intended Audience :: Science/Research",
    
    # License
    "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
    
    # Topics
    "Topic :: Scientific/Engineering :: Medical Science Apps.",
    "Topic :: Scientific/Engineering :: Bio-Informatics",
    "Topic :: Scientific/Engineering :: Artificial Intelligence",
    "Topic :: Scientific/Engineering :: Information Analysis",
    "Topic :: Software Development :: Libraries :: Python Modules",
    
    # Python Versions
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    
    # OS
    "Operating System :: OS Independent",
    
    # Language
    "Natural Language :: English",

    ],
    keywords=(
        "neuroscience, brain, datasets, neuroimaging, MRI, Alzheimer, Parkinson, "
    "epilepsy, ADHD, dopamine, serotonin, cognitive impairment, sleep, "
    "biomarkers, brain size, gray matter, white matter, schizophrenia, "
    "migraine, PTSD, depression, CBT, dementia, machine learning, "
    "data science, statistics, research, neurology, psychiatry"
    ),
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.5",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov",
            "black",
            "flake8",
            "mypy",
        ],
        "docs": [
            "mkdocs",
            "mkdocs-material",
        ],
    },
    license="GPL-3.0",
    zip_safe=False,
)