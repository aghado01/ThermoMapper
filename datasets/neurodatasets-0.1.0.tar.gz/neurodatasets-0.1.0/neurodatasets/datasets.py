"""
Datasets registry for neurodatasets.
"""
DATASETS = {
    "parkinson_voice_features": {
        "filename": "parkinson_001.csv",
        "Original name": "parkinson",
        "Original R package": "PPforest (v0.1.3)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains biomedical voice recordings from patients with and without Parkinson's disease."
    },

    "hippocampus_lesions": {
        "filename": "hippocampus_lesions_001.csv",
        "Original name": "HippocampusLesions",
        "Original R package": "abd (v0.2-8)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains spatial memory scores and hippocampus lesion percentages from patients with hippocampal damage."
    },

    "language_brains": {
        "filename": "language_brains_001.csv",
        "Original name": "LanguageBrains",
        "Original R package": "abd (v0.2-8)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains language proficiency and gray matter density measurements in bilingual subjects."
    },

    "neanderthal_brains": {
        "filename": "neanderthal_brains_001.csv",
        "Original name": "NeanderthalBrains",
        "Original R package": "abd (v0.2-8)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains brain size and body mass measurements from Neanderthals and early modern humans."
    },

    "sleep_performance": {
        "filename": "sleep_performance_001.csv",
        "Original name": "SleepAndPerformance",
        "Original R package": "abd (v0.2-8)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains slow-wave sleep measurements and spatial learning improvements in human subjects."
    },

    "cocaine_dopamine": {
        "filename": "cocaine_dopamine_001.csv",
        "Original name": "CocaineDopamine",
        "Original R package": "abd (v0.2-8)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains dopamine receptor blockage percentages and perceived high levels measured by PET scans in human subjects."
    },

    "chimp_brains": {
        "filename": "chimp_brains_001.csv",
        "Original name": "ChimpBrains",
        "Original R package": "abd (v0.2-8)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains Brodmann's area 44 asymmetry measurements in chimpanzees by sex."
    },

    "brain_expression": {
        "filename": "brain_expression_001.csv",
        "Original name": "BrainExpression",
        "Original R package": "abd (v0.2-8)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains PLP1 gene expression levels in individuals from control, schizophrenia, and bipolar disorder groups."
    },

    "alzheimers_biomarkers": {
        "filename": "alzheimer_disease_001.csv",
        "Original name": "ad_data",
        "Original R package": "modeldata (v1.4.0)",
        "Repository": "CRAN",
        "License": "MIT + file LICENSE",
        "description": "This dataset contains plasma protein and biomarker expression levels from patients for Alzheimer's disease research."
    },

    "parkinson_speech": {
        "filename": "parkinson_speech_001.csv",
        "Original name": "pd_speech",
        "Original R package": "modeldata (v1.4.0)",
        "Repository": "CRAN",
        "License": "MIT + file LICENSE",
        "description": "This dataset contains speech signal features including jitter, shimmer and harmonicity measurements for Parkinson's disease classification."
    },

    "alzheimer_smoking": {
        "filename": "alzheimer_smoking_001.csv",
        "Original name": "alzheimer",
        "Original R package": "coin (v1.4-3)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains smoking history and disease classification from a case-control study on Alzheimer's disease."
    },

    "brain_size_iq": {
        "filename": "brain_size_iq_001.csv",
        "Original name": "Brainsz",
        "Original R package": "sur (v1.0.4)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains brain size, IQ scores and gender data from psychology students for intelligence research."
    },

    "mammal_brains": {
        "filename": "mammals_large_brains_001.csv",
        "Original name": "case0902",
        "Original R package": "Sleuth3 (v1.0-6)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains brain weight, body weight, gestation length and litter size across 96 mammal species."
    },

    "blood_brain_barrier": {
        "filename": "blood_brain_barrier_001.csv",
        "Original name": "case1102",
        "Original R package": "Sleuth3 (v1.0-6)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains brain and liver radiation counts from rats used to study blood-brain barrier disruption treatments."
    },

    "brain_litter_size": {
        "filename": "brain_weights_mammals_001.csv",
        "Original name": "ex0333",
        "Original R package": "Sleuth3 (v1.0-6)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains relative brain sizes and litter size categories across mammal species."
    },

    "violin_brain_activity": {
        "filename": "brain_activity_violin_001.csv",
        "Original name": "ex0728",
        "Original R package": "Sleuth3 (v1.0-6)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains years of musical training and brain activity measurements in violin and string players."
    },

    "oasis_longitudinal_mri": {
        "filename": "oasis_001.csv",
        "Original name": "oasis",
        "Original R package": "jointest (v1.0)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains longitudinal MRI data including cognitive and demographic measurements from demented and nondemented older adults."
    },

    "epileptic_qol": {
        "filename": "epilepsy_quality_life_001.csv",
        "Original name": "epileptic.qol",
        "Original R package": "joineRML (v0.4.7)",
        "Repository": "CRAN",
        "License": "GPL-3 | file LICENSE",
        "description": "This dataset contains quality of life, anxiety and depression scores from epilepsy patients treated with carbamazepine or lamotrigine over two years."
    },

    "epilepsy_seizures": {
        "filename": "epileptic_seizures_001.csv",
        "Original name": "epilepsy",
        "Original R package": "faraway (v1.0.9)",
        "Repository": "CRAN",
        "License": "GPL",
        "description": "This dataset contains seizure counts from epileptic patients in a clinical trial comparing Progabide drug treatment against placebo."
    },

    "sexual_abuse_ptsd": {
        "filename": "ptsd_abused_adult_females.csv",
        "Original name": "sexab",
        "Original R package": "faraway (v1.0.9)",
        "Repository": "CRAN",
        "License": "GPL",
        "description": "This dataset contains PTSD and physical abuse scores from adult females with and without a history of childhood sexual abuse."
    },

    "migraine_treatment": {
        "filename": "migraine_headaches_001.csv",
        "Original name": "KosteckiDillon",
        "Original R package": "carData (v3.0-5)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains daily migraine records and medication use from patients undergoing migraine treatment."
    },

    "dopamine_schizophrenic": {
        "filename": "dopamine_schizophrenic_001.csv",
        "Original name": "Dopamine",
        "Original R package": "BSDA (v1.2.2)",
        "Repository": "CRAN",
        "License": "GPL-3",
        "description": "This dataset contains dopamine b-hydroxylase activity measurements from schizophrenic patients treated with an antipsychotic drug."
    },

    "frontal_lobe_adhd": {
        "filename": "adhd_frontal_lobe.csv",
        "Original name": "frontal2D",
        "Original R package": "NBR (v0.1.5)",
        "Repository": "CRAN",
        "License": "GPL (>= 3)",
        "description": "This dataset contains frontal lobe functional connectivity measurements between brain areas in ADHD patients and control subjects."
    },

    "schizophrenia_diagnosis": {
        "filename": "schizophrenia_patients_001.csv",
        "Original name": "cobre61",
        "Original R package": "fcaR (v1.2.2)",
        "Repository": "CRAN",
        "License": "GPL-3",
        "description": "This dataset contains neurological and clinical symptom scores from patients for schizophrenia differential diagnosis."
    },

    "adolescent_mental_health": {
        "filename": "adolescent_mental_health.csv",
        "Original name": "AddHealth",
        "Original R package": "heplots (v1.7.4)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains depression and anxiety scores from a longitudinal study of adolescent mental health."
    },

    "neurocognitive_psychiatric": {
        "filename": "neurocognitive_measures.csv",
        "Original name": "NeuroCog",
        "Original R package": "heplots (v1.7.4)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains neurocognitive performance scores in schizophrenia and schizoaffective patients."
    },

    "guinea_pig_brains": {
        "filename": "guinea_pig_brains.csv",
        "Original name": "paulsen",
        "Original R package": "boot (v1.3-32)",
        "Repository": "CRAN",
        "License": "Unlimited",
        "description": "This dataset contains peak amplitude measurements of spontaneous brain cell currents in guinea pigs for quantal neurotransmission analysis."
    },

    "adhd_symptoms": {
        "filename": "adhd_symptom_children.csv",
        "Original name": "ADHD",
        "Original R package": "bgms (v0.1.6.1)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains ADHD symptom ratings from children aged 6 to 8 diagnosed and non-diagnosed with ADHD."
    },

    "allen_brain_atlas_pheno": {
        "filename": "phenotype_brain_samples.csv",
        "Original name": "aba_pheno_data",
        "Original R package": "BRETIGEA (v1.0.3)",
        "Repository": "CRAN",
        "License": "MIT + file LICENSE",
        "description": "This dataset contains brain sample phenotype data from the Allen Brain Atlas Aging, Dementia, and TBI study."
    },

    "human_brain_markers": {
        "filename": "markers_human_brain.csv",
        "Original name": "markers_df_human_brain",
        "Original R package": "BRETIGEA (v1.0.3)",
        "Repository": "CRAN",
        "License": "MIT + file LICENSE",
        "description": "This dataset contains marker genes estimated from a meta-analysis of brain cell gene expression data from humans only."
    },

    "mouse_brain_markers": {
        "filename": "markers_mouse_brain.csv",
        "Original name": "markers_df_mouse_brain",
        "Original R package": "BRETIGEA (v1.0.3)",
        "Repository": "CRAN",
        "License": "MIT + file LICENSE",
        "description": "This dataset contains marker genes for six major mouse brain cell types."
    },

    "gray_matter_patterns": {
        "filename": "gray_matter_patterns.csv",
        "Original name": "EP.GM",
        "Original R package": "RVIpkg (v0.3.2)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains expected patterns of gray matter derived from large-scale meta-analyses by the ENIGMA consortium."
    },

    "white_matter_patterns": {
        "filename": "whitematter_patterns.csv",
        "Original name": "EP.WM",
        "Original R package": "RVIpkg (v0.3.2)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains expected patterns of white matter derived from large-scale meta-analyses by the ENIGMA consortium."
    },

    "encephalitis_herpes": {
        "filename": "encephalitis_herpes_001.csv",
        "Original name": "encephalitis",
        "Original R package": "catdata (v1.2.4)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains cases of herpes encephalitis in children observed in Bavaria and Lower Saxony between 1980 and 1993."
    },

    "tumor_mobile_phone": {
        "filename": "brain_tumor_mobile.csv",
        "Original name": "tumour",
        "Original R package": "discovr (v1.0.0)",
        "Repository": "CRAN",
        "License": "GPL-3",
        "description": "This dataset contains data on mobile phone usage and brain tumour size measurements across 120 participants."
    },

    "sleep_study_college": {
        "filename": "sleep_study_001.csv",
        "Original name": "SleepStudy",
        "Original R package": "Lock5Data (v4.0.1)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains data on sleep patterns and academic performance for college students."
    },

    "football_brain": {
        "filename": "football_brain_001.csv",
        "Original name": "FootballBrain",
        "Original R package": "Lock5Data (v4.0.1)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains brain measurements for football players and non-football players grouped by concussion history."
    },

    "crash_corticosteroids": {
        "filename": "corticosteroids_tbi_001.csv",
        "Original name": "crash",
        "Original R package": "ratesci (v1.0.0)",
        "Repository": "CRAN",
        "License": "GPL (>= 3)",
        "description": "This dataset contains data from a systematic review of corticosteroids effect on mortality in traumatic brain injury."
    },

    "neocortex_artiodactyl": {
        "filename": "neocortex_001.csv",
        "Original name": "neocortex",
        "Original R package": "slouch (v2.1.5)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains morphological data on neocortex area, brain size, and body size for 43 artiodactyl species."
    },

    "sleep_stages_cts": {
        "filename": "sleep_stages_001.csv",
        "Original name": "SleepStages",
        "Original R package": "ctsfeatures (v1.2.2)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains categorical time series of sleep stages recorded from different subjects."
    },

    "stuttering_metronome": {
        "filename": "stuttering_001.csv",
        "Original name": "stuttering",
        "Original R package": "nsm3data (v0.1)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains data on the influence of metronome rhythmicity on speech fluency in stuttering subjects."
    },

    "medial_temporal_lobe": {
        "filename": "medial_temporal_lobe.csv",
        "Original name": "mtl",
        "Original R package": "openintro (v2.5.0)",
        "Repository": "CRAN",
        "License": "GPL-3",
        "description": "This dataset contains medial temporal lobe (MTL) measures and cognitive test scores for adult participants."
    },

    "down_syndrome_births": {
        "filename": "down_syndrome_babies.csv",
        "Original name": "down",
        "Original R package": "segmented (v2.2-1)",
        "Repository": "CRAN",
        "License": "GPL",
        "description": "This dataset contains the number of Down syndrome cases and total births by maternal age group."
    },

    "serotonin_pet_binding": {
        "filename": "serotonin_001.csv",
        "Original name": "serotonin",
        "Original R package": "lava (v1.8.1)",
        "Repository": "CRAN",
        "License": "GPL-3",
        "description": "This dataset contains simulated PET imaging measurements of 5-HT2A receptor and serotonin transporter (SERT)."
    },

    "zika_outbreak_simulated": {
        "filename": "zika_simulated_data.csv",
        "Original name": "zika_learner",
        "Original R package": "SelectionBias (v2.1.0)",
        "Repository": "CRAN",
        "License": "MIT + file LICENSE",
        "description": "This dataset contains simulated data emulating a Zika outbreak in Brazil."
    },

    "pituitary_fissure_size": {
        "filename": "pituitary_size_001.csv",
        "Original name": "pituitary",
        "Original R package": "isotone (v1.1-2)",
        "Repository": "CRAN",
        "License": "GPL-2",
        "description": "This dataset contains measurements of pituitary fissure size in girls aged 8 to 14 years."
    },

    "amyloid_cognitive_impairment": {
        "filename": "amyloid_cognitive.csv",
        "Original name": "Amyloid",
        "Original R package": "Stat2Data (v2.0.0)",
        "Repository": "CRAN",
        "License": "GPL-3",
        "description": "This dataset contains amyloid-beta levels and cognitive impairment status for a sample of Catholic priests."
    },

    "wechsler_wais_scores": {
        "filename": "wechsler_test_001.csv",
        "Original name": "wechsler",
        "Original R package": "gorica (v0.1.5)",
        "Repository": "CRAN",
        "License": "GPL (>= 3)",
        "description": "This dataset contains Wechsler Adult Intelligence Scale-Revised (WAIS-R) test scores and educational status for adult participants."
    },

    "meditation_brain_study": {
        "filename": "meditation_brain_001.csv",
        "Original name": "data_meditationbrain",
        "Original R package": "esci (v1.0.9)",
        "Repository": "CRAN",
        "License": "GPL-3",
        "description": "This dataset contains pretest and posttest brain measurements for meditation and control groups."
    },

    "cbt_depression_studies": {
        "filename": "cbt_depression_001.csv",
        "Original name": "dat.lopez2019",
        "Original R package": "metadat (v1.4-0)",
        "Repository": "CRAN",
        "License": "GPL (>= 2)",
        "description": "This dataset contains results from 76 studies evaluating the effectiveness of cognitive behavioral therapy (CBT) for depression in adults."
    },

}

__all__ = ["DATASETS"]