"""
Basic usage example for neurodatasets

Run:
    python basic_usage.py
"""

import neurodatasets as nd

print("=== neurodatasets: Basic Usage Example ===\n")

# Load a dataset
print("Loading 'schizophrenia_diagnosis' dataset...")
schizophrenia_001 = nd.load_dataset("schizophrenia_diagnosis")

# Show basic information
print("\nFirst 5 rows:")
print(schizophrenia_001.head())

print("\nDataset shape:")
print(schizophrenia_001.shape)

print("\nColumn names:")
print(list(schizophrenia_001.columns))

# Load another dataset
print("\nLoading 'mouse_brain_markers' dataset...")
mouse_brain = nd.load_dataset("mouse_brain_markers")

print("\nFirst 5 rows:")
print(mouse_brain.head())

# List all available datasets
print("Available datasets:")
print(nd.list_datasets())

# Describe a dataset
print("\nDataset description:")
print(nd.describe("mouse_brain_markers"))

print("\nDone.")